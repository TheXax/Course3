file(REMOVE_RECURSE
  "CMakeFiles/demoserviced.dir/Linux/demoserviced.c.o"
  "CMakeFiles/demoserviced.dir/Linux/demoserviced.c.o.d"
  "bin/demoserviced"
  "bin/demoserviced.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/demoserviced.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
